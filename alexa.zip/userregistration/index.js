'use strict';

const Alexa = require('alexa-sdk');
var APP_ID="amzn1.ask.skill.3f8fbfc5-9042-4b24-a938-cff7f7bf261e";
const https = require('https');

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.appId=APP_ID;
    alexa.execute();
};

const handlers = {
    'LaunchRequest':function(){
        var speechOutput="Welcome To Allegheny Registration Portal .To get started please say : Register me ";
        var repromptSpeechOutput="Please say : Register me ";
        this.emit(":ask",speechOutput,repromptSpeechOutput);
    },
    'AlleghenyUserRegistration':function(){
        var FullName = this.event.request.intent.slots.FullName.value;
        var DateOfBirth = this.event.request.intent.slots.DateOfBirth.value;
        var ZipCode = this.event.request.intent.slots.ZipCode.value;
        //var speechOutput="Your registration output is "+FullName+" , "+DateOfBirth+" , "+ZipCode;
        var requestURL="https://homeautomationalpha-developer-edition.ap5.force.com/services/apexrest/alexauserreg?fullname="+FullName+"&dateofbirth="+DateOfBirth+"&zipcode="+ZipCode;
        https.get(requestURL, (resp) => {
            let data = '';
            resp.on('data', (chunk) => {
              data += chunk;
            });
            resp.on('end', () => {
                this.emit(":tell","Your details were successfully saved! Thank You !");
            });
          }).on("error", (err) => {
            this.emit(":tell","There was an error processing your request.");
          });
        
        
    },
    'Unhandled': function () {
        //log the event sent by the Alexa Service in human readable format
        console.log(JSON.stringify(this.event));
        let skillId, requestType, dialogState, intent ,intentName, intentConfirmationStatus, slotArray, slots, count;

        try {
            //Parse necessary data from JSON object using dot notation
            //build output strings and check for undefined
            skillId = this.event.session.application.applicationId;
            requestType = "The request type is, "+this.event.request.type+" .";
            dialogState = this.event.request.dialogState;
            intent = this.event.request.intent;
            if (intent != undefined) {
                intentName = " The intent name is, "+this.event.request.intent.name+" .";
                slotArray = this.event.request.intent.slots;
                intentConfirmationStatus = this.event.request.intent.confirmationStatus;

                if (intentConfirmationStatus != "NONE" && intentConfirmationStatus != undefined ) {
                    intentConfirmationStatus = " and its confirmation status is "+ intentConfirmationStatus+" . ";
                    intentName = intentName+intentConfirmationStatus;
                }
            } else {
                intentName = "";
                slotArray = "";
                intentConfirmationStatus = "";
            }

            slots = "";
            count = 0;

            if (slotArray == undefined || slots == undefined) {
                slots = "";
            }

            //Iterating through slot array
            for (let slot in slotArray) {
                count += 1;
                let slotName = slotArray[slot].name;
                let slotValue = slotArray[slot].value;
                let slotConfirmationStatus = slotArray[slot].confirmationStatus;
                slots = slots + "The <say-as interpret-as='ordinal'>"+count+"</say-as> slot is, " + slotName + ", its value is, " +slotValue;

                if (slotConfirmationStatus!= undefined && slotConfirmationStatus != "NONE") {
                  slots = slots+" and its confirmation status is "+slotConfirmationStatus+" . ";
                } else {
                  slots = slots+" . ";
                }
            }

            //Delegate to Dialog Manager when needed
            //<reference to docs>
            if (dialogState == "STARTED" || dialogState == "IN_PROGRESS") {
              this.emit(":delegate");
            }
        } catch(err) {
            console.log("Error: " + err.message);
        }

        let speechOutput = "Your end point received a request, here's a breakdown. " + requestType + " " + intentName + slots;
        let cardTitle = "Skill ID: " + skillId;
        let cardContent = speechOutput;

        this.response.cardRenderer(cardTitle, cardContent);
        this.response.speak(speechOutput);
        this.emit(':responseReady');
  }
};